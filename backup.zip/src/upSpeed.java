public interface upSpeed {

}
