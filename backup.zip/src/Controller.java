public class Controller {
    private int time;

}
