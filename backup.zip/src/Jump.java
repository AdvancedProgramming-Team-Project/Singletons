public interface Jump {

    public void jump(Position p);

}
