public class Debuff extends Item implements upSpeed {

    public void changeDown(){
    }

}
