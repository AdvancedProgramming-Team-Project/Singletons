public interface Fever {

    public void fever();

}
