public interface Collision {

    public void enemy_collide(Position p);

    public void item_collide(Position p);

}
