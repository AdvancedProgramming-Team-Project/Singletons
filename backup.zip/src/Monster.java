public class Monster extends Enemy {
    private int x;
    private int y;

    public void delete(Position p){
    }

    public void create(Position p){
    }

    public void p_die(Position p){
    }

}
