public class Hong extends Player implements Shield {
    private int hp;
    private int speed;
    private int accel;
    private int x;
    private int y;
    private int cool_time;
    private int cool_check;

}
