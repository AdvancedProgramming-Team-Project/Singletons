public interface Shield {

    public void shield();

}
