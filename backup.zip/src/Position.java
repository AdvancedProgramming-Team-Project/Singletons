public class Position {
    private Monster[MAX_M] m;
    private Obstacle[MAX_O] o;
    private Item[MAX_IT] it;
    private int MAX_M;
    private int MAX_O;
    private int MAX_IT;
    private int[] pos_arr;
    private int[] exist_arr;

}
