public interface Die {

    public void gameOver();

}
