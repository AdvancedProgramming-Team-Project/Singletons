public interface FullHP {

    public void fullHP();

}
