public abstract class Enemy implements set {
    private static int E_WIDTH;
    private int angle;

}
