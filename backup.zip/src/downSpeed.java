public interface downSpeed {

}
