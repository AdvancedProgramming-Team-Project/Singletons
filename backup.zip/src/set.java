public interface set {

    public void create();

    public void delete();

}
