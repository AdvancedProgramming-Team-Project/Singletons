public class Buff extends Item implements downSpeed {

    public void changeUp(){
    }

}
