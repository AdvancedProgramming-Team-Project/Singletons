public abstract class Item implements set {
    private static int MAX_CH_SPEED;
    private int angle;

    public void changeSpeed(int speed){
    }

    public void delete(Position p){
    }

    public void create(Position p){
    }

    public void change_Speed(){
    }

}
