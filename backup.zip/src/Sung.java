public class Sung extends Player implements Fieldclean {
    private int hp;
    private int speed;
    private int accel;
    private int x;
    private int y;
    private int cool_time;
    private int cool_check;

}
