public interface Fieldclean {

    public void fieldClean();

}
