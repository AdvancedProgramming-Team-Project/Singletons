public class Obstacle extends Enemy {

    public void create(Position p){
    }

    public void p_die(Position p){
    }

}
