public interface Move {

    public void move(Position p);

}
