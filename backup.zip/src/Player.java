public abstract class Player implements Move, Collision, Jump, Die {
    private static int MAX_HP;
    private static int MAX_SPEED;
    private static int P_WIDTH;
    private static int count;
    private int hp;
    private Item it;
    private boolean exist;
    public int count;
    private int p_angle;

    public void skill(){
    }

}
